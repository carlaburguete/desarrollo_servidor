<?php $__env->startSection("titulo"); ?>
    <h1 class="text-info text-center">Dar de alta nuevo alumno</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("opciones"); ?>
    <a href="<?php echo e(route('alumno.index')); ?>" class="btn btn-primary m-3">Volver al listado</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("contenido"); ?>
    <div class="col-8">
    <form action="<?php echo e(route('alumno.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-check col-10"  name="nombre" placeholder="Inserta nombre"><br>

            <label for="dni">DNI</label>
            <input type="text" class="form-check col-10" placeholder="DNI" name ="dni"><br>

            <label for="nombre">Dirección </label>
            <input type="text" class="form-check col-10" placeholder="Dirección" name="direccion"><br>

            <label for="telefono">Teléfono</label>
            <input type="text" class="form-check col-10" placeholder="Teléfono" name="telefono"><br>

        </div>
        <button type="submit" class="btn btn-outline-success">Guardar</button>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("alumno.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/CRUD/resources/views/alumno/create.blade.php ENDPATH**/ ?>