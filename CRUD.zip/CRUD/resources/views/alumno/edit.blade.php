@extends("alumno.layout")

@section("titulo")
    <h1 class="text-info text-center">Dar de alta nuevo alumno</h1>
@endsection

@section("opciones")
    <a href="{{route('alumno.index')}}" class="btn btn-primary m-3">Volver al listado</a>
@endsection

@section("contenido")
    <div class="col-8">
    <form action="{{route('alumno.update',[$alumno])}}" method="POST">
        @csrf
        @method("PUT")
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-check col-10" value="{{$alumno->nombre}}" name="nombre" placeholder="Inserta nombre"><br>

            <label for="dni">DNI</label>
            <input type="text" class="form-check col-10" placeholder="DNI" value="{{$alumno->dni}}"name ="dni"><br>

            <label for="nombre">Dirección </label>
            <input type="text" class="form-check col-10" placeholder="Dirección" value="{{$alumno->direccion}}"name="direccion"><br>

            <label for="telefono">Teléfono</label>
            <input type="text" class="form-check col-10" placeholder="Teléfono" value="{{$alumno->telefono}}"name="telefono"><br>

        </div>
        <button type="submit" class="btn btn-outline-success">Guardar</button>
    </form>
    </div>
@endsection

