@extends("alumno.layout")

@section("titulo")
    <h1 class="text-info text-center">Dar de alta nuevo alumno</h1>
@endsection

@section("opciones")
    <a href="{{route('alumno.index')}}" class="btn btn-primary m-3">Volver al listado</a>
@endsection

@section("contenido")
    <div class="col-8">
    <form action="{{route('alumno.store')}}" method="POST">
        @csrf
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-check col-10"  name="nombre" placeholder="Inserta nombre"><br>

            <label for="dni">DNI</label>
            <input type="text" class="form-check col-10" placeholder="DNI" name ="dni"><br>

            <label for="nombre">Dirección </label>
            <input type="text" class="form-check col-10" placeholder="Dirección" name="direccion"><br>

            <label for="telefono">Teléfono</label>
            <input type="text" class="form-check col-10" placeholder="Teléfono" name="telefono"><br>

        </div>
        <button type="submit" class="btn btn-outline-success">Guardar</button>
    </form>
    </div>
@endsection
