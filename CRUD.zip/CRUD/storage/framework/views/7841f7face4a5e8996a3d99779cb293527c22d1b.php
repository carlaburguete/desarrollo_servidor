<?php $__env->startSection("titulo"); ?>
    <h1 class="text-info text-center">Listado de alumnos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("opciones"); ?>
    <div class="col-12">
        <a href="<?php echo e(route("alumno.create")); ?>" class="btn btn-primary m-3">Agregar</a>
        <?php $__env->stopSection(); ?>
        <?php if(isset($msj)): ?>
        <?php $__env->startSection("mensaje"); ?>
            <h5 class="text-uppercase alert-warning"><?php echo e($msj); ?></h5>
        <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <?php $__env->startSection("contenido"); ?>
            <table class="table table-responsive table-striped table-bordered">
                <thead class="table-dark">
                <tr>
                    <th>Nombre</th>
                    <th>Dni</th>
                    <th>Direccion</th>
                    <th>Teléfono</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alumno->nombre); ?></td>
                        <td><?php echo e($alumno->dni); ?></td>
                        <td><?php echo e($alumno->direccion); ?></td>
                        <td><?php echo e($alumno->telefono); ?></td>
                        <td>
                            <a class="btn btn-outline-info" href="<?php echo e(route("alumno.edit",[$alumno])); ?>">
                                <i class="fa fa-user-edit"></i>
                            </a>
                        </td>
                        <td>
                            <form action="<?php echo e(route('alumno.destroy', [$alumno])); ?>" method="post">
                                <?php echo method_field("delete"); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-danger">
                                    <i class="fa fa-trash-restore"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("alumno.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/CRUD/resources/views/alumno/listado.blade.php ENDPATH**/ ?>